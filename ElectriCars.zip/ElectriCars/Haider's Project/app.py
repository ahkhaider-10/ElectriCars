from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, render_template, request
import pandas as pd
import pickle
import model as m
# model = pickle.load(open('Project1.pkl', 'rb'))
# model = pickle.load(open('Project_linear1000.pkl', 'rb'))
model = pickle.load(open('Project_dtr.pkl', 'rb'))
df = pd.read_csv("ElectricCarData_Clean_Me.csv")

df['PriceRupees'] = df['PriceEuro'] * 80
df['Segment'].replace(['A', 'B', 'C', 'D', 'E', 'F', 'N', 'S'], [
                      1, 2, 3, 4, 5, 6, 7, 8], inplace=True)

df['BodyStyle'].replace(['Sedan', 'Hatchback', 'Liftback', 'SUV', 'Pickup', 'MPV', 'Cabrio',
                         'SPV', 'Station'], [1, 2, 3, 4, 5, 6, 7, 8, 9], inplace=True)

df['RapidCharge'].replace(['Yes', 'No'], [1, 0], inplace=True)
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def a():
    acc = request.form.get('acc')
    range = request.form.get('range')
    ts = request.form.get('ts')
    eff = request.form.get('eff')
    seg = request.form.get('seg')
    st = request.form.get('st')
    bs = request.form.get('bs')
    rc = request.form.get('rc')

    q = pd.DataFrame([[acc, range, ts, eff, seg, st, bs, rc]], columns=[
                     'AccelSec', 'Range_Km', 'TopSpeed_KmH', 'Efficiency_WhKm', 'Segment', 'Seats', 'BodyStyle', 'RapidCharge'])
    # return acc
    prdct = m.predict_model(q)
    return str(prdct[0])

@app.route('/prediction.html')
def prediction():
    segments = sorted(df['Segment'].unique())
    seats = sorted(df['Seats'].unique())
    bodystyle = sorted(df['BodyStyle'].unique())
    return render_template('prediction.html', seats=seats, segments=segments, bodystyle=bodystyle)

@app.route('/range.html')
def range():
    return render_template('range.html')

@app.route('/rangevbattery.html')
def rangevbattery():
    return render_template('rangevbattery.html')

@app.route('/acceleration.html')
def acceleration():
    return render_template('acceleration.html')

@app.route('/bodystyle.html')
def bodystyle():
    return render_template('bodystyle.html')

@app.route('/efficiency.html')
def efficiency():
    return render_template('efficiency.html')


@app.route('/fastcharge.html')
def fastcharge():
    return render_template('fastcharge.html')


@app.route('/maxrange.html')
def maxrange():
    return render_template('maxrange.html')


@app.route('/rangevefficiency.html')
def rangevefficiency():
    return render_template('rangevefficiency.html')


@app.route('/rangevprice.html')
def rangevprice():
    return render_template('rangevprice.html')


@app.route('/seats.html')
def seats():
    return render_template('seats.html')


@app.route('/segments.html')
def segments():
    return render_template('segments.html')


@app.route('/topspeed.html')
def topspeed():
    return render_template('topspeed.html')


if __name__ == '__main__':
    app.run(debug=True, port=1000)