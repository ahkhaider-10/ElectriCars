from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
import pickle
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
data = pickle.load(open("data.pkl", "rb"))
df = pd.DataFrame(data)
x = df[['AccelSec', 'Range_Km', 'TopSpeed_KmH',
        'Efficiency_WhKm', 'Segment', 'Seats', 'BodyStyle', 'RapidCharge']]
y = df['PriceRupees']

dtr = DecisionTreeRegressor()
scores1 = []
for i in range(1000):
    X_train, X_test, Y_train, Y_test = train_test_split(
        x, y, test_size=0.1, random_state=i)
SI = SimpleImputer(missing_values=np.nan, strategy='mean')
pipe = make_pipeline(SI, dtr)
pipe.fit(X_train, Y_train)

#     pred = dtr.predict(X_test)
#     scores1.append(r2_score(Y_test, pred))
# # print(np.argmax(scores1))
# print('Accuracy:', scores1[np.argmax(scores1)] * 100)


def predict_model(arr):
    result = pipe.predict(arr)
    return result
