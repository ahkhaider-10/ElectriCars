from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
import pickle
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import pandas as pd
import numpy as np

df = pd.read_csv('ElectricCarData_Clean_Me.csv')
df['PriceRupees'] = df['PriceEuro']*80

x = df[['AccelSec', 'Range_Km', 'TopSpeed_KmH',
        'Efficiency_WhKm', 'Seats']]
y = df['PriceRupees']

lr = LinearRegression()
x = df[['AccelSec', 'Range_Km', 'TopSpeed_KmH',
        'Efficiency_WhKm', 'Seats']]
y = df['PriceRupees']
scores = []
for i in range(1000):
    X_train, X_test, y_train, y_test = train_test_split(
        x, y, test_size=0.3, random_state=i)
    lr.fit(X_train, y_train)
    pred = lr.predict(X_test)
    scores.append(r2_score(y_test, pred))
print(np.argmax(scores))
print(scores[np.argmax(scores)])

ff = pd.DataFrame([[4.6, 460, 233, 161, 5]], columns=['AccelSec',
                  'Range_Km', 'TopSpeed_KmH', 'Efficiency_WhKm', 'Seats'])
ahk = lr.predict(ff)
print('Price in Rupees:', ahk[0])

dtr = DecisionTreeRegressor()
scores1 = []
for i in range(1000):
    X_train, X_test, y_train, y_test = train_test_split(
        x, y, test_size=0.1, random_state=i)
    dtr.fit(X_train, y_train)
    pred = dtr.predict(X_test)
    scores1.append(r2_score(y_test, pred))
print(np.argmax(scores1))
print(scores1[np.argmax(scores1)])

# SimpleImputer(missing_values=np.nan, strategy='mean')
pipe = make_pipeline(dtr, SimpleImputer(
    missing_values=np.nan, strategy='mean'))
pipe.fit(X_train, y_train)
pred = pipe.predict(X_test)
r2_score(y_test, pred)
#pickle.dump(pipe, open('Project1.pkl','wb'))

ff1 = pd.DataFrame([[3, 500, 300, 190, 5]], columns=['AccelSec',
                                                     'Range_Km', 'TopSpeed_KmH', 'Efficiency_WhKm', 'Seats'])
ahk1 = dtr.predict(ff1)
print('Price in Rupees:', ahk1[0])

ff2 = pd.DataFrame([[2.1, 970, 410, 206, 4]], columns=['AccelSec',
                                                       'Range_Km', 'TopSpeed_KmH', 'Efficiency_WhKm', 'Seats'])
ahk2 = dtr.predict(ff2)
print('Price in Rupees:', ahk2[0])

ff3 = pd.DataFrame([[22.4, 190, 130, 194, 5]], columns=['AccelSec',
                                                        'Range_Km', 'TopSpeed_KmH', 'Efficiency_WhKm', 'Seats'])
ahk3 = dtr.predict(ff3)
print('Price in Rupees:', ahk3[0])
